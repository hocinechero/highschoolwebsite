// دالة إرسال البريد — تنشر داخل Supabase Edge Functions
// الاستخدام: supabase functions deploy send-email
// الأسرار:   supabase secrets set RESEND_API_KEY=re_xxx
//            supabase secrets set SCHOOL_EMAIL=dardar.bouzid.school@gmail.com
//            supabase secrets set MAIL_FROM=school@yourdomain.com

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req: Request) => {
  // طلبات CORS قبل الإرسال الفعلي
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: cors });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ ok: false, error: "POST only" }), {
      status: 405,
      headers: { ...cors, "Content-Type": "application/json" },
    });
  }

  try {
    const { subject, body } = await req.json();

    if (!subject || !body) {
      return new Response(JSON.stringify({ ok: false, error: "subject and body are required" }), {
        status: 400,
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    const apiKey = Deno.env.get("RESEND_API_KEY");
    const to = Deno.env.get("SCHOOL_EMAIL") ?? "dardar.bouzid.school@gmail.com";
    const from = Deno.env.get("MAIL_FROM") ?? "onboarding@resend.dev";

    if (!apiKey) {
      return new Response(JSON.stringify({ ok: false, error: "RESEND_API_KEY not set" }), {
        status: 500,
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ from, to: [to], subject, text: body }),
    });

    if (!res.ok) {
      const detail = await res.text().catch(() => "");
      console.error("Resend error:", res.status, detail);
      return new Response(JSON.stringify({ ok: false }), {
        status: 502,
        headers: { ...cors, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...cors, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("send-email error:", e);
    return new Response(JSON.stringify({ ok: false, error: "invalid request" }), {
      status: 400,
      headers: { ...cors, "Content-Type": "application/json" },
    });
  }
});
