-- ============================================================
-- ثانوية دردار بوزيد — مخطط قاعدة البيانات (Supabase / PostgreSQL)
-- نفّذ هذا الملف كاملاً في SQL Editor داخل مشروع Supabase
-- ============================================================

-- أقسام المؤسسة
create table public.classes (
  id bigint generated always as identity primary key,
  name text not null unique,
  level int not null check (level between 0 and 2)
);

-- الإعلانات
create table public.announcements (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  date date not null default current_date,
  title text not null,
  category text not null default 'عام',
  body text not null,
  image_url text,
  featured boolean not null default false
);

-- حصص الجدول الدراسي
create table public.schedule (
  id bigint generated always as identity primary key,
  class_id bigint not null references public.classes(id) on delete cascade,
  day int not null check (day between 0 and 4),
  start_time text not null,
  end_time text not null,
  subject text not null,
  room text
);

-- الاختبارات
create table public.exams (
  id bigint generated always as identity primary key,
  date date not null,
  type text not null default 'فرض',
  level int not null default 0,
  subject text not null,
  scope text
);

-- الوثائق الداخلية (للأسرة التربوية)
create table public.documents (
  id bigint generated always as identity primary key,
  title text not null,
  kind text,
  size text,
  url text
);

-- طلبات مواعيد الأولياء
create table public.appointments (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  ref text unique,
  parent_name text not null,
  student_name text not null,
  class_name text,
  phone text,
  preferred_date date,
  slot text,
  reason text,
  status text not null default 'جديد'
);

-- جدول الأساتذة المصرّح لهم (اربطه بحسابات Authentication)
create table public.staff (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text
);

-- دالة صلاحية: هل المستخدم الحالي من الأساتذة؟
create or replace function public.is_staff()
returns boolean
language sql stable
as $$
  select exists (select 1 from public.staff where user_id = auth.uid());
$$;

-- ============================================================
-- تفعيل الحماية (RLS)
-- ============================================================

alter table public.classes enable row level security;
alter table public.announcements enable row level security;
alter table public.schedule enable row level security;
alter table public.exams enable row level security;
alter table public.documents enable row level security;
alter table public.appointments enable row level security;
alter table public.staff enable row level security;

-- القراءة عامة للجميع (الموقع العام يقرأ بدون حساب)
create policy "public read classes" on public.classes for select using (true);
create policy "public read announcements" on public.announcements for select using (true);
create policy "public read schedule" on public.schedule for select using (true);
create policy "public read exams" on public.exams for select using (true);
create policy "public read documents" on public.documents for select using (true);

-- الكتابة: الأساتذة فقط (بعد تسجيل الدخول عبر admin.html)
create policy "staff insert announcements" on public.announcements for insert to authenticated with check (public.is_staff());
create policy "staff update announcements" on public.announcements for update to authenticated using (public.is_staff());
create policy "staff delete announcements" on public.announcements for delete to authenticated using (public.is_staff());

create policy "staff insert classes" on public.classes for insert to authenticated with check (public.is_staff());
create policy "staff delete classes" on public.classes for delete to authenticated using (public.is_staff());

create policy "staff insert schedule" on public.schedule for insert to authenticated with check (public.is_staff());
create policy "staff delete schedule" on public.schedule for delete to authenticated using (public.is_staff());

create policy "staff insert exams" on public.exams for insert to authenticated with check (public.is_staff());
create policy "staff delete exams" on public.exams for delete to authenticated using (public.is_staff());

create policy "staff insert documents" on public.documents for insert to authenticated with check (public.is_staff());
create policy "staff delete documents" on public.documents for delete to authenticated using (public.is_staff());

-- الطلبات: أي زائر يرسل، الأساتذة فقط يقرؤون ويعدّلون
create policy "anyone submits appointments" on public.appointments for insert with check (true);
create policy "staff read appointments" on public.appointments for select to authenticated using (public.is_staff());
create policy "staff update appointments" on public.appointments for update to authenticated using (public.is_staff());
create policy "staff delete appointments" on public.appointments for delete to authenticated using (public.is_staff());

-- جدول الأساتذة نفسه: يقرؤه الأساتذة فقط
create policy "staff read staff" on public.staff for select to authenticated using (public.is_staff());

-- ============================================================
-- بيانات أولية (اختياري — يزرع الأقسام الثلاثة)
-- ============================================================

insert into public.classes (name, level) values
  ('السنة الأولى ثانوي — 1', 0),
  ('السنة الثانية ثانوي — 1', 1),
  ('السنة الثالثة ثانوي — 1', 2);

-- ============================================================
-- بعد التنفيذ:
-- 1) أنشئ حسابات الأساتذة من: Authentication → Users → Add user
-- 2) اربط كل حساب بالصلاحية:
--      insert into public.staff (user_id, full_name)
--      values ('<معرّف المستخدم>', '<الاسم الكامل>');
-- ============================================================
